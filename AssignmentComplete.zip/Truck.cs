﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;

namespace AssignmentComplete
{
    public class Truck : ITruck
    {
        private Texture2D truck;
        private Texture2D containerBox;
        private IContainer container;
        private Vector2 position;
        private Vector2 velocity;
        private bool driving = false;
        
        public Truck(Texture2D truck, Texture2D containerbox, Vector2 position, Vector2 velocity, IContainer container)
        {
            this.truck = truck;
            this.containerBox = containerbox;
            this.position = position;
            this.velocity = velocity;
            this.container = container;
        }
        
        public IContainer Container
        {
            get
            {
                return this.container;
            }
        }

        public Vector2 Position
        {
            get
            {
                return this.position;
            }
        }

        public Vector2 Velocity
        {
            get
            {
                return this.velocity;
            }
        }

        public void AddContainer(IContainer container)
        {
            throw new NotImplementedException();
        }

        public void Draw(SpriteBatch spriteBatch)
        {
            spriteBatch.Draw(truck, this.position, Color.White);
        }

        public void StartEngine()
        {
            this.driving = true;
        }

        public void Update(float dt)
        {
            this.position.X = this.position.X + this.velocity.X;
        }
    }
}
